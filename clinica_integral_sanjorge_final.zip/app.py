import os
from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

APP_SECRET = "S4nj0rg32027#"
app = Flask(__name__)
app.secret_key = APP_SECRET
DB_PATH = os.path.join(os.path.dirname(__file__), 'database.db')

def crear_tablas():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        cargo TEXT NOT NULL,
        usuario TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        tipo TEXT NOT NULL DEFAULT 'usuario'
    )""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS cuentas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER,
        paciente TEXT NOT NULL,
        servicio TEXT NOT NULL,
        valor REAL NOT NULL,
        fecha TEXT NOT NULL,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    )""")
    conn.commit()
    conn.close()

crear_tablas()

@app.route('/')
def index():
    if 'usuario' in session:
        return redirect(url_for('listar'))
    return render_template('index.html')

@app.route('/registro_usuario', methods=['GET','POST'])
def registro_usuario():
    if request.method == 'POST':
        nombre = request.form['nombre']
        cargo = request.form['cargo']
        usuario = request.form['usuario']
        password = generate_password_hash(request.form['password'])
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO usuarios (nombre, cargo, usuario, password) VALUES (?, ?, ?, ?)", (nombre, cargo, usuario, password))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('registro_usuario.html', error='El usuario ya existe. Intenta con otro.')
        conn.close()
        return redirect(url_for('login'))
    return render_template('registro_usuario.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        password = request.form['password']
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE usuario=?", (usuario,))
        user = cursor.fetchone()
        conn.close()
        if user and check_password_hash(user[4], password):
            session['usuario'] = user[1]
            session['usuario_id'] = user[0]
            session['tipo'] = user[5]
            return redirect(url_for('listar'))
        else:
            return render_template('login.html', error='Usuario o contraseña incorrectos')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/registrar', methods=['GET','POST'])
def registrar():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        paciente = request.form['paciente']
        servicio = request.form['servicio']
        valor = float(request.form['valor'])
        fecha = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        usuario_id = session['usuario_id']
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO cuentas (usuario_id, paciente, servicio, valor, fecha) VALUES (?, ?, ?, ?, ?)", (usuario_id, paciente, servicio, valor, fecha))
        conn.commit()
        conn.close()
        return redirect(url_for('listar'))
    return render_template('registrar.html', usuario=session.get('usuario'))

@app.route('/listar')
def listar():
    if 'usuario' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    if session.get('tipo') == 'admin':
        cursor.execute("SELECT c.id, u.nombre, u.cargo, c.paciente, c.servicio, c.valor, c.fecha FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id ORDER BY c.fecha DESC")
    else:
        cursor.execute("SELECT c.id, u.nombre, u.cargo, c.paciente, c.servicio, c.valor, c.fecha FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id WHERE u.id=? ORDER BY c.fecha DESC", (session.get('usuario_id'),))
    cuentas = cursor.fetchall()
    conn.close()
    return render_template('listar.html', cuentas=cuentas, usuario=session.get('usuario'), tipo=session.get('tipo'))

@app.route('/usuarios')
def usuarios():
    if 'usuario' not in session or session.get('tipo') != 'admin':
        return redirect(url_for('login'))
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT id, nombre, cargo, usuario, tipo FROM usuarios ORDER BY nombre')
    users = cursor.fetchall()
    conn.close()
    return render_template('usuarios.html', users=users)

@app.route('/cuentas_registradas')
def cuentas_registradas():
    if 'usuario' not in session or session.get('tipo') != 'admin':
        return redirect(url_for('login'))
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT c.id, u.nombre, u.cargo, c.paciente, c.servicio, c.valor, c.fecha FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id ORDER BY c.fecha DESC')
    cuentas = cursor.fetchall()
    conn.close()
    return render_template('cuentas_registradas.html', cuentas=cuentas)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)